<div id="navigation">
			<div id="pagenav">
				<b>Store Window</b><br><br>
				<table>
				<tr>	
				<td><b><i>Product</i></b></td>
				<td><b><i>Price</i></b></td>
				</tr>
				</table>
				<?php while($product = mysql_fetch_array($products) ) { ?>
				<table>
				<tr>
				<td><?php print $product['item'];?></td>
				<td>Rs.<?php print $product['prize']?></td>
				</tr>
				</table>
				<?php } 
				mysql_close();
				?>
				<br><br>
				Please <b>Login</b> to access the store or <b>Sign Up</b> if you're not registered.<br><br><br><marquee>Get tubelights,CFL'S,wires at very genuine price</marquee><br><br><br>
<html><body><img src="copper.jpg" alt="notfound" style="width:95px;height:95px;"><img src="bulb.jpg" alt="notfound" style="width:95px;height:95px;"><img src="tubelight.jpg" alt="notfound" style="width:95px;height:95px;"><img src="wire.jpg" alt="notfound" style="width:95px;height:95px;"><img src="cfl.jpg" alt="notfound" style="width:95px;height:95px;"><img src="otheritem.jpg" alt="notfound" style="width:95px;height:95px;"><br><br>
<center><a href="contact.html">Contact Us</a></center></body></html>

			</div>
		<img src="http://localhost/image_floder/subfolder/your_image.jpeg" /></div>
