<?php

require_once("config.php");
require_once("class_session.php");

session_start();

if(isset($_GET['logout'])) {
        session_destroy();
        header('Location: ../index.php');
}

$link = mysql_connect("localhost", "root", "user123");
if (!$link) {
        die ("Error connecting to the database: " . mysql_error());
}

$db_selected = mysql_select_db(online_elec, $link);
if (!$db_selected) {
        die ("Error selecting the database: " . mysql_error());
}

$error_log = false;

include("header.html");

?>
	<div id="center">
                <div id="bar">
                       <?php include("logstatus.php"); ?>
		</div>
		<div id="navigation">
                        <div id="pagenav">
				<?php
				/* Login Error */
				if($error_log == true) { ?>
					<a href="../index.php">Go back to the Login page</a>
				<?php
				}
				else { ?>
					<b>Your Cart</b><br><br>
					<table>
					<tr>
                                	<td><b><i>Product</i></b></td>
					<td><b><i>Quantity</i></b></td>
					</tr>
					</table>
				<?php
                                	$query = "SELECT * FROM cart INNER JOIN products ON cart.id_item=products.id WHERE sid='" .$_SESSION['username']."'";
                                	$res = mysql_query($query,$link) or die(mysql_error());
					$t = 0;
                              		while($record = mysql_fetch_assoc($res)) {?>
						<table>
						<tr>
						<td><?php print $record['item'];?></td>
						<td><?php print $record['quantity'];?></td>
						</tr>
						</table>
				<?php
						$t += $record['prize']*$record['quantity'];
					} ?>
					<br><hr><br>
					<b><i>Total:</i></b>Rs.<?php print $t;?><br>
					<br><hr><br>
				
					<b><a href="store.php">Go back to the store</a></b>
				<?php
					mysql_close();
				} ?>
			</div>
                </div>
        </div>
<?php

include("footer.html");

?>

