<?php

// Database constants
define("HOST", "localhost");
define("USER", "root");
define("PW", "user123");
define("DB", "online_elec");

// Session Class constants
define("SESSIONS", "sessions");
define("SESSIONID", "sid");
define("SESSIONDATA", "sdata");
define("SESSIONEXPIRE", "sexpire");

?>
